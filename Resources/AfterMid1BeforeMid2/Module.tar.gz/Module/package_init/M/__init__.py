print 'importing M'
import Foo
