print '-- importing Foo of P'
def foo():
  print '---- Hello P!'

foo()
