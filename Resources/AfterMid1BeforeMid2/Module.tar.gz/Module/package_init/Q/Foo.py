print '-- importing Foo of Q'
def foo():
  print '---- Hello Q!'

foo()
