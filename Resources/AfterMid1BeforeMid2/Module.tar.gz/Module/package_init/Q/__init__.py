print 'importing Q'
import Foo
