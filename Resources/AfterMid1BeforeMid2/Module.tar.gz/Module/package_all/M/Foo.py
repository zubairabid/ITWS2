print '-- importing Foo of M'
def foo():
  print '---- Hello M!'

foo()
