import package_all as pkg

print 'inside test code'
pkg.P.Foo.foo()
pkg.Q.Foo.foo()
pkg.M.Foo.foo()






