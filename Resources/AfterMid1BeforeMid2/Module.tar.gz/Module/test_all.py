# use of __all__ in __init__.py inside package_all
# code below should be tried independently
# will work if __init__ in P, Q, M are set appropriately
#__all__ = [P,M]
from package_all import *
P
M
Q






