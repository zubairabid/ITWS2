from flask import Flask, redirect,url_for, render_template, request
import model 

app = Flask(__name__)
app.secret_key ="Demo-ITW2"
model.create()
 
@app.route("/")
def index():
   return render_template("index.html")

@app.route('/register')
def register():
   return render_template('adduser.html')

@app.route('/unregister')
def unregister():
   return render_template('deleteuser.html')

@app.route('/showall')
def showall():
   rows,msg = model.getAll()
   return render_template('showall.html', rows = rows, message=msg)

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
   if request.method == 'POST':
      res, msg = model.addUser(request)
      return render_template("result.html", result=res, message=msg)
   else:
      return render_template("adduser.html")

@app.route('/deleterec',methods = ['POST', 'GET'])
def deleterec():
   if request.method == 'POST':
      res, msg = model.deleteUser(request)
      return render_template("result.html", result=res, message=msg)
   else:
       return render_template("deleteuser.html")
   #return redirect(url_for("showall"))   
         
if __name__ == '__main__':
   app.run(debug = True)
