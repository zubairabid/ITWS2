import sqlite3 as sql

# A model that supports following interface:
# create() : creates a users table in database if not already there
# getAll() : fetch information on all users
# addUser(request) : add a new user from request object to database if not already present
# deleteUser(request) : delete an existing user represented by request object from the database

def create():
 try:
   with sql.connect("database.db") as con:
     print "Opened database successfully";
 
     con.execute('''CREATE TABLE users (name TEXT NOT NULL, 
                   phone TEXT NOT NULL, 
                   interests TEXT, 
                   id INT PRIMARY KEY NOT NULL, 
                   marks INT);''')
     print "Table created successfully";
 except:
   print "Table already exists"

def getAll():
  msg = "Records were fetched successfully"
  try:  
    with sql.connect("database.db") as con:
      con.row_factory = sql.Row
      cur = con.cursor()
      cur.execute("select * from users where name is not null") 
      rows = cur.fetchall()
      for row in rows:
           print "row=" +  row["name"]
      return (rows,msg)
  except:
      print "connection failed"
      return ([], "connection failed")
 
  
def addUser(request):
  try:
   user = request.args['nm']
   marks = request.args['mrks']
   phone = request.args['phone']
   hobbies= request.args['interests']
   ide = request.args['id']
   res = request.args
   msg = "Record successfully added"
  
   with sql.connect("database.db") as con:
      cur = con.cursor()
      
      # check to see if this user already exists in the system.
      sqlQuery = "select name from users where name ='" + user + "';"
      cur.execute(sqlQuery)
      print "after executing sql query"
      row = cur.fetchone()
      print row
         
      if row:
         msg = "User with name %s is already present, insertion failed!"%user
      else:
         cur.execute("INSERT INTO users (name, phone,interests,id,marks)  VALUES (?,?,?,?,?)",(user,phone,hobbies,ide,marks))            
         con.commit()
      
      print msg, '---', dict
      return  (res, msg)
  except:
      msg = "Unexpected Error in insert operation"
      print msg
      return ({}, msg)

def deleteUser(request):
 try:
   print "inside deleteuser"
   user = request.args['nm']
   ide = request.args['id']
   msg = "Record successfully deleted"
   with sql.connect("database.db") as con:
      cur = con.cursor()
      cur.execute("DELETE FROM users  WHERE id = ? and name = ?", (ide, user))
      con.commit()
      print "user deleted"
      return (request.args, msg)
 except:
      msg = "error in delete operation"
      print "in delete - exception handler"
      return ({}, msg)
 
